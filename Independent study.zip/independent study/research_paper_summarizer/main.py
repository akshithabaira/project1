"""
Main Application Entry Point
Research Paper Summarizer and Reviewer
"""

import argparse
import json
import os
from dotenv import load_dotenv
from src.pipeline.agent_pipeline import ResearchPaperPipeline

# Load environment variables
load_dotenv()


def print_results(result: dict, verbose: bool = False):
    """Pretty print the results"""
    print("\n" + "="*80)
    print("RESEARCH PAPER ANALYSIS RESULTS")
    print("="*80 + "\n")
    
    if 'error' in result:
        print(f"Error: {result['error']}")
        return
    
    if 'all_results' in result:
        results = result['all_results']
    elif 'results' in result:
        results = [result['results']] if isinstance(result['results'], dict) else result['results']
    else:
        results = []
    
    for idx, paper_result in enumerate(results, 1):
        print(f"\n{'='*80}")
        print(f"PAPER {idx}")
        print(f"{'='*80}\n")
        
        metadata = paper_result.get('metadata', {})
        print(f"Title: {metadata.get('title', 'Unknown')}")
        print(f"Authors: {metadata.get('authors', 'Unknown')}")
        print(f"Published: {metadata.get('published', 'Unknown')}")
        print(f"arXiv ID: {metadata.get('arxiv_id', 'Unknown')}")
        print(f"URL: {metadata.get('url', 'N/A')}\n")
        
        # Summary
        summary = paper_result.get('summary', {})
        if summary.get('full_summary'):
            print("-"*80)
            print("SUMMARY")
            print("-"*80)
            print(summary['full_summary'])
            print()
        
        # Review
        review = paper_result.get('review', {})
        if review.get('full_review'):
            print("-"*80)
            print("PEER REVIEW")
            print("-"*80)
            print(review['full_review'])
            print()
        
        # Metrics
        metrics = paper_result.get('metrics', {})
        if metrics.get('summary_metrics'):
            print("-"*80)
            print("EVALUATION METRICS")
            print("-"*80)
            summary_metrics = metrics['summary_metrics']
            print(f"ROUGE-1 F1: {summary_metrics.get('rouge1', 0):.4f}")
            print(f"ROUGE-2 F1: {summary_metrics.get('rouge2', 0):.4f}")
            print(f"ROUGE-L F1: {summary_metrics.get('rougeL', 0):.4f}")
            print(f"BLEU Score: {summary_metrics.get('bleu', 0):.4f}")
            print()
        
        if verbose:
            # Show section summaries
            if summary.get('section_summaries'):
                print("-"*80)
                print("SECTION SUMMARIES")
                print("-"*80)
                for section, section_summary in summary['section_summaries'].items():
                    print(f"\n{section.upper()}:")
                    print(section_summary)
                print()
            
            # Show structured review components
            if review:
                print("-"*80)
                print("STRUCTURED REVIEW COMPONENTS")
                print("-"*80)
                for key, value in review.items():
                    if key != 'full_review' and value:
                        print(f"\n{key.upper().replace('_', ' ')}:")
                        print(value)
                print()


def save_results(result: dict, output_file: str):
    """Save results to JSON file"""
    # Convert Document objects to strings for JSON serialization
    def convert_to_serializable(obj):
        if hasattr(obj, 'page_content'):
            return obj.page_content
        if isinstance(obj, dict):
            return {k: convert_to_serializable(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [convert_to_serializable(item) for item in obj]
        return obj
    
    serializable_result = convert_to_serializable(result)
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(serializable_result, f, indent=2, ensure_ascii=False)
    
    print(f"\nResults saved to {output_file}")


def main():
    parser = argparse.ArgumentParser(
        description="Research Paper Summarizer and Reviewer - Automated LangChain Pipeline"
    )
    parser.add_argument(
        '--query',
        type=str,
        required=True,
        help='Search query (keywords, title, or author name)'
    )
    parser.add_argument(
        '--query-type',
        type=str,
        default='keywords',
        choices=['keywords', 'title', 'author'],
        help='Type of query (default: keywords)'
    )
    parser.add_argument(
        '--max-results',
        type=int,
        default=1,
        help='Maximum number of papers to process (default: 1)'
    )
    parser.add_argument(
        '--summarizer-model',
        type=str,
        default='openai',
        choices=['openai', 'bart', 'pegasus'],
        help='Summarization model type (default: openai)'
    )
    parser.add_argument(
        '--review-model',
        type=str,
        default='gpt-3.5-turbo',
        help='Review generation model (default: gpt-3.5-turbo)'
    )
    parser.add_argument(
        '--use-free-models',
        action='store_true',
        help='Use free HuggingFace models instead of OpenAI (no API key required)'
    )
    parser.add_argument(
        '--output',
        type=str,
        help='Output JSON file path (optional)'
    )
    parser.add_argument(
        '--verbose',
        action='store_true',
        help='Show detailed output including section summaries'
    )
    parser.add_argument(
        '--no-eval',
        action='store_true',
        help='Skip evaluation metrics computation'
    )
    
    args = parser.parse_args()
    
    # Check for API key (only warn if not using free models)
    if not args.use_free_models and not os.getenv("OPENAI_API_KEY"):
        print("Warning: OPENAI_API_KEY not found in environment variables.")
        print("You can either:")
        print("  1. Set OPENAI_API_KEY in .env file (requires payment)")
        print("  2. Use --use-free-models flag to use free HuggingFace models")
        print("\nProceeding with free models...")
        args.use_free_models = True
    
    # Initialize pipeline
    print("Initializing Research Paper Pipeline...")
    if args.use_free_models:
        print("Using FREE models (no OpenAI API required)")
    pipeline = ResearchPaperPipeline(
        summarizer_model=args.summarizer_model,
        review_model=args.review_model,
        max_results=args.max_results,
        use_free_models=args.use_free_models
    )
    
    # Process paper
    result = pipeline.process_paper(
        query=args.query,
        query_type=args.query_type,
        evaluate=not args.no_eval
    )
    
    # Print results
    print_results(result, verbose=args.verbose)
    
    # Save results if output file specified
    if args.output:
        save_results(result, args.output)


if __name__ == "__main__":
    main()