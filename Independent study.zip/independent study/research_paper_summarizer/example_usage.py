"""
Example Usage Script
Demonstrates how to use the Research Paper Summarizer and Reviewer
"""

from dotenv import load_dotenv
from src.pipeline.agent_pipeline import ResearchPaperPipeline

# Load environment variables
load_dotenv()


def example_basic_usage():
    """Basic example: Process a paper by keywords"""
    print("=" * 80)
    print("Example 1: Basic Usage - Search by Keywords")
    print("=" * 80)
    
    pipeline = ResearchPaperPipeline(
        summarizer_model="openai",
        review_model="gpt-3.5-turbo",
        max_results=1
    )
    
    result = pipeline.process_paper(
        query="transformer attention mechanism",
        query_type="keywords",
        evaluate=True
    )
    
    if 'error' in result:
        print(f"Error: {result['error']}")
        return
    
    # Print basic results
    if result.get('results'):
        paper = result['results'] if isinstance(result['results'], dict) else result['results'][0]
        print(f"\nTitle: {paper['metadata'].get('title', 'Unknown')}")
        print(f"\nSummary Preview:")
        summary = paper.get('summary', {}).get('full_summary', '')
        print(summary[:500] + "..." if len(summary) > 500 else summary)


def example_by_title():
    """Example: Process a paper by exact title"""
    print("\n" + "=" * 80)
    print("Example 2: Search by Title")
    print("=" * 80)
    
    pipeline = ResearchPaperPipeline(max_results=1)
    
    result = pipeline.process_paper(
        query="Attention Is All You Need",
        query_type="title",
        evaluate=False  # Skip evaluation for faster processing
    )
    
    if 'error' in result:
        print(f"Error: {result['error']}")
        return
    
    if result.get('results'):
        paper = result['results'] if isinstance(result['results'], dict) else result['results'][0]
        print(f"\nTitle: {paper['metadata'].get('title', 'Unknown')}")
        print(f"Authors: {paper['metadata'].get('authors', 'Unknown')}")
        print(f"URL: {paper['metadata'].get('url', 'N/A')}")


def example_multiple_papers():
    """Example: Process multiple papers"""
    print("\n" + "=" * 80)
    print("Example 3: Process Multiple Papers")
    print("=" * 80)
    
    pipeline = ResearchPaperPipeline(max_results=2)
    
    queries = ["neural networks", "deep learning"]
    result = pipeline.process_multiple_papers(queries, query_type="keywords")
    
    print(f"\nProcessed {result['num_queries']} queries")
    print(f"Total papers processed: {len(result.get('results', []))}")


def example_get_paper_info():
    """Example: Get paper information without full processing"""
    print("\n" + "=" * 80)
    print("Example 4: Get Paper Information Only")
    print("=" * 80)
    
    pipeline = ResearchPaperPipeline(max_results=3)
    
    papers = pipeline.get_paper_info("machine learning", query_type="keywords")
    
    print(f"\nFound {len(papers)} papers:")
    for i, paper in enumerate(papers, 1):
        print(f"\n{i}. {paper.get('title', 'Unknown')}")
        print(f"   Authors: {paper.get('authors', 'Unknown')}")
        print(f"   URL: {paper.get('url', 'N/A')}")


if __name__ == "__main__":
    print("\n" + "=" * 80)
    print("Research Paper Summarizer - Example Usage")
    print("=" * 80)
    print("\nNote: These examples require OPENAI_API_KEY to be set in .env file")
    print("=" * 80 + "\n")
    
    # Run examples (comment out ones you don't want to run)
    try:
        example_basic_usage()
        # example_by_title()
        # example_multiple_papers()
        # example_get_paper_info()
    except Exception as e:
        print(f"\nError running example: {e}")
        import traceback
        traceback.print_exc()

