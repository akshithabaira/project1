# Research Paper Summarizer and Reviewer

An Automated LangChain-Based Pipeline for Scientific Literature Analysis

**Project Members:** VIHAS ADI, AKSHITHA BAIRA

## Overview

This project implements an end-to-end automated system for retrieving, summarizing, and reviewing research papers from arXiv. It uses LangChain to orchestrate a pipeline that:

1. Retrieves scientific papers from arXiv using keywords, titles, or author names
2. Processes and segments papers into structured sections
3. Generates abstractive summaries using transformer-based models
4. Produces peer-review style feedback with structured analysis
5. Evaluates generated summaries using ROUGE and BLEU metrics

## Features

- **Paper Retrieval**: Uses LangChain's ArxivLoader to fetch papers from arXiv
- **Text Processing**: Segments papers into sections (abstract, introduction, methodology, results, conclusion)
- **Summarization**: Supports multiple models:
  - OpenAI GPT models (default)
  - BART (Facebook)
  - PEGASUS (Google)
- **Review Generation**: Automated peer-review style analysis covering:
  - Contributions
  - Strengths
  - Weaknesses and Limitations
  - Technical Quality
  - Clarity and Presentation
  - Future Directions
  - Overall Assessment
- **Evaluation Metrics**: ROUGE-1, ROUGE-2, ROUGE-L, and BLEU scores

## Installation

### Prerequisites

- Python 3.8 or higher
- pip package manager

### Setup

1. Clone or download this repository

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. **Choose your model option:**

   **Option A: Use FREE models (No API key needed!)**
   ```bash
   # Just use the --use-free-models flag
   python main.py --query "machine learning" --use-free-models
   ```
   See [FREE_MODELS_GUIDE.md](FREE_MODELS_GUIDE.md) for details.

   **Option B: Use OpenAI API (requires payment)**
   - Create a `.env` file in the project root
   - Add your OpenAI API key to `.env`:
     ```
     OPENAI_API_KEY=your_actual_api_key_here
     ```
   - Get your API key from: https://platform.openai.com/api-keys

4. (Optional) Download NLTK data:
```python
python -c "import nltk; nltk.download('punkt')"
```

> **Note**: The system works completely free without OpenAI API! See [FREE_MODELS_GUIDE.md](FREE_MODELS_GUIDE.md) for details.

## Usage

### Basic Usage

Process a paper by keywords:
```bash
python main.py --query "transformer attention mechanism"
```

Process a paper by title:
```bash
python main.py --query "Attention Is All You Need" --query-type title
```

Process a paper by author:
```bash
python main.py --query "Vaswani" --query-type author
```

### Advanced Options

**With OpenAI (paid):**
```bash
python main.py \
  --query "machine learning" \
  --query-type keywords \
  --max-results 2 \
  --summarizer-model openai \
  --review-model gpt-3.5-turbo \
  --output results.json \
  --verbose
```

**With Free Models (no API key needed):**
```bash
python main.py \
  --query "machine learning" \
  --query-type keywords \
  --max-results 2 \
  --summarizer-model bart \
  --use-free-models \
  --output results.json \
  --verbose
```

### Web UI (Recommended)

The application now includes a modern web-based user interface built with Streamlit. This provides an intuitive way to interact with all features without using the command line.

**Launch the UI:**
```bash
streamlit run app.py
```

The UI will automatically open in your default web browser at `http://localhost:8501`.

**UI Features:**
- 📝 Interactive form for all configuration options
- 🔍 Real-time progress tracking
- 📊 Beautiful visualization of results
- 📥 Download results as JSON
- ⚙️ Easy model selection (free or premium)
- 📑 Expandable sections for summaries and reviews
- 📈 Visual metrics display (ROUGE, BLEU scores)

**UI Configuration:**
- **Search Query**: Enter keywords, title, or author name
- **Query Type**: Select from dropdown (keywords/title/author)
- **Model Settings**: Choose between free models or OpenAI (requires API key)
- **Processing Options**: Adjust max results, evaluation, and verbosity
- **Results Display**: View all results in organized, expandable sections

All terminal functionality is available through the UI with a more user-friendly experience!

### Command Line Arguments

- `--query`: Search query (keywords, title, or author name) - **Required**
- `--query-type`: Type of query (`keywords`, `title`, `author`) - Default: `keywords`
- `--max-results`: Maximum number of papers to process - Default: 1
- `--summarizer-model`: Summarization model (`openai`, `bart`, `pegasus`) - Default: `openai`
- `--review-model`: Review generation model - Default: `gpt-3.5-turbo`
- `--use-free-models`: Use free HuggingFace models instead of OpenAI (no API key required)
- `--output`: Output JSON file path (optional)
- `--verbose`: Show detailed output including section summaries
- `--no-eval`: Skip evaluation metrics computation

### Testing Setup

Test your installation:
```bash
python test_setup.py
```

This will verify:
- All required packages are installed
- Project modules can be imported
- Environment variables are set
- Basic functionality works

## Project Structure

```
research_paper_summarizer/
├── main.py                      # Main application entry point (CLI)
├── app.py                       # Streamlit web UI application
├── test_setup.py                # Setup verification script
├── requirements.txt             # Python dependencies
├── .env.example                 # Environment variables template
├── README.md                    # This file
└── src/
    ├── __init__.py
    ├── retrieval/
    │   ├── __init__.py
    │   └── paper_retriever.py   # arXiv paper retrieval
    ├── processing/
    │   ├── __init__.py
    │   └── text_processor.py    # Text segmentation and processing
    ├── summarization/
    │   ├── __init__.py
    │   └── summarizer.py        # Abstractive summarization
    ├── review/
    │   ├── __init__.py
    │   └── review_generator.py  # Peer-review generation
    ├── evaluation/
    │   ├── __init__.py
    │   └── evaluation_metrics.py # ROUGE and BLEU metrics
    └── pipeline/
        ├── __init__.py
        └── agent_pipeline.py    # End-to-end pipeline orchestration
```

## Example Output

The system generates structured output including:

1. **Paper Metadata**: Title, authors, publication date, arXiv ID, URL
2. **Summary**: Comprehensive summary of the paper
3. **Peer Review**: Structured review with:
   - Contributions
   - Strengths
   - Weaknesses
   - Technical Quality
   - Clarity
   - Future Directions
   - Overall Assessment
4. **Evaluation Metrics**: ROUGE and BLEU scores (if evaluation enabled)

## Technical Details

### Summarization Approach

The system uses a **map-reduce** approach for long documents:
1. **Map**: Summarize each chunk/section independently
2. **Reduce**: Combine section summaries into a coherent full summary

### Review Generation

Uses structured prompts with LangChain chains to generate peer-review style feedback. The review covers all standard aspects expected in academic peer review.

### Evaluation

- **ROUGE**: Measures overlap of n-grams between generated and reference summaries
- **BLEU**: Measures precision of n-gram matches

## Limitations

1. **API Costs**: Using OpenAI models incurs API costs. Consider using local models (BART/PEGASUS) for cost savings.
2. **Token Limits**: Very long papers may be truncated or require multiple API calls.
3. **Model Quality**: Summary and review quality depends on the chosen model.
4. **Reference Availability**: Evaluation metrics require reference summaries (abstracts are used as proxies).

## Future Improvements

- Support for more summarization models
- Batch processing of multiple papers
- Web interface for easier interaction
- Integration with more paper sources (PubMed, IEEE Xplore, etc.)
- Custom evaluation metrics
- Human feedback collection system

## Relevant Literature

1. **REMOR**: Automated Peer Review Generation with LLM Reasoning and Multi-Objective Reinforcement Learning (arXiv, 2025)
2. **Cohan et al. (2018)**: A Discourse-Aware Attention Model for Abstractive Summarization of Long Documents (arXiv)
3. **Choudhary & Dwivedi (2021)**: Automatic Summarization of Scientific Articles: A Survey (Information Processing & Management)

## License

This project is for educational purposes.

## Contact

For questions or issues, please contact the project members.

