"""
Review Generation Module
Generates peer-review style feedback with structured analysis
"""

import os
from typing import Dict, List, Optional
try:
    from langchain_core.prompts import PromptTemplate
except ImportError:
    try:
        from langchain.prompts import PromptTemplate
    except ImportError:
        from langchain_core.prompts import PromptTemplate

try:
    from langchain.chains import LLMChain
    LLM_CHAIN_AVAILABLE = True
except ImportError:
    LLM_CHAIN_AVAILABLE = False

# Try to import OpenAI (optional)
try:
    from langchain_openai import ChatOpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

# Try to import HuggingFace models (free alternative)
try:
    from langchain_huggingface import HuggingFacePipeline
    HUGGINGFACE_PIPELINE_AVAILABLE = True
except ImportError:
    try:
        from langchain_community.llms import HuggingFacePipeline
        HUGGINGFACE_PIPELINE_AVAILABLE = True
    except ImportError:
        HuggingFacePipeline = None
        HUGGINGFACE_PIPELINE_AVAILABLE = False

try:
    from transformers import (
        pipeline,
        AutoTokenizer,
        AutoModelForCausalLM,
        AutoModelForSeq2SeqLM,
    )
    import torch
    HUGGINGFACE_AVAILABLE = True
except ImportError:
    HUGGINGFACE_AVAILABLE = False

try:
    from langchain_core.documents import Document
except ImportError:
    # Fallback for older LangChain versions
    try:
        from langchain.schema import Document
    except ImportError:
        from langchain_core.documents import Document


class ReviewGenerator:
    """
    Generates structured peer-review style feedback for research papers
    Supports both OpenAI (paid) and HuggingFace (free) models
    """
    
    def __init__(self, model_name: str = "gpt-3.5-turbo", use_free_model: bool = False):
        """
        Initialize the review generator
        
        Args:
            model_name: Model name (OpenAI model name or HuggingFace model path)
            use_free_model: If True, use free HuggingFace models instead of OpenAI
        """
        self.model_name = model_name
        self.use_free_model = use_free_model
        self.llm = self._initialize_llm()
        
        if self.llm is None:
            raise ValueError("Could not initialize any language model. Please install transformers for free models or set OPENAI_API_KEY for OpenAI models.")
        
        self.review_prompt = self._create_review_prompt()
        if LLM_CHAIN_AVAILABLE and self.llm:
            try:
                self.review_chain = LLMChain(llm=self.llm, prompt=self.review_prompt)
            except:
                self.review_chain = None
        else:
            self.review_chain = None
    
    def _initialize_llm(self):
        """Initialize the language model (OpenAI or HuggingFace)"""
        if self.use_free_model or not OPENAI_AVAILABLE:
            # Use free HuggingFace models
            return self._initialize_huggingface_model()
        else:
            # Try OpenAI first
            return self._initialize_openai_model()
    
    def _initialize_openai_model(self):
        """Initialize OpenAI model"""
        if not OPENAI_AVAILABLE:
            return None
        
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            print("Warning: OPENAI_API_KEY not found. Falling back to free models...")
            return self._initialize_huggingface_model()
        
        try:
            return ChatOpenAI(
                model=self.model_name,
                temperature=0.7,
                max_tokens=2000
            )
        except Exception as e:
            print(f"Error initializing OpenAI model: {e}")
            print("Falling back to free HuggingFace models...")
            return self._initialize_huggingface_model()
    
    def _initialize_huggingface_model(self):
        """Initialize free HuggingFace model"""
        if not HUGGINGFACE_AVAILABLE or not HUGGINGFACE_PIPELINE_AVAILABLE:
            print("Warning: HuggingFace models not available. Install transformers and langchain-huggingface packages.")
            return None
        
        # Allow user-specified model; default to BART for better seq2seq generation
        model_name = self.model_name or "facebook/bart-large-cnn"
        
        try:
            print(f"Loading free HuggingFace model: {model_name} (this may take a minute on first run)...")
            tokenizer = AutoTokenizer.from_pretrained(model_name)
            
            # Decide model class based on architecture
            if "bart" in model_name.lower() or "pegasus" in model_name.lower() or "t5" in model_name.lower():
                model = AutoModelForSeq2SeqLM.from_pretrained(model_name)
                task = "text2text-generation"
                generation_kwargs = {
                    "max_new_tokens": 200,
                    "do_sample": True,
                    "temperature": 0.7,
                    "top_p": 0.9,
                    "truncation": True,
                }
            else:
                model = AutoModelForCausalLM.from_pretrained(model_name)
                task = "text-generation"
                generation_kwargs = {
                    "max_new_tokens": 200,
                    "do_sample": True,
                    "temperature": 0.7,
                    "top_p": 0.9,
                    "truncation": True,
                }
            
            # Set pad_token if not set
            if tokenizer.pad_token is None:
                tokenizer.pad_token = tokenizer.eos_token
            
            generation_kwargs["pad_token_id"] = tokenizer.eos_token_id
            
            hf_pipeline = pipeline(
                task,
                model=model,
                tokenizer=tokenizer,
                device=0 if torch.cuda.is_available() else -1,
                **generation_kwargs,
            )
            
            return HuggingFacePipeline(pipeline=hf_pipeline)
        except Exception as e:
            print(f"Error loading HuggingFace model: {e}")
            print("Note: Review generation requires either OpenAI API key or HuggingFace models.")
            return None
    
    def _create_review_prompt(self) -> PromptTemplate:
        """Create structured prompt for review generation"""
        return PromptTemplate(
            template="""
You are an expert peer reviewer evaluating a research paper. Please provide a comprehensive review in the following structured format:

PAPER TITLE: {title}

PAPER CONTENT:
{content}

Please provide a detailed peer review covering:

1. CONTRIBUTIONS:
   - What are the main contributions of this paper?
   - What novel ideas or methods does it introduce?
   - How does it advance the field?

2. STRENGTHS:
   - What are the key strengths of this work?
   - What aspects are particularly well-executed?
   - What makes this paper valuable?

3. WEAKNESSES AND LIMITATIONS:
   - What are the main weaknesses or limitations?
   - Are there methodological concerns?
   - What could be improved?

4. TECHNICAL QUALITY:
   - Is the methodology sound?
   - Are the experiments well-designed?
   - Is the evaluation appropriate?

5. CLARITY AND PRESENTATION:
   - Is the paper well-written and clear?
   - Are the figures and tables helpful?
   - Is the organization logical?

6. FUTURE DIRECTIONS:
   - What are potential future research directions?
   - What extensions or improvements could be made?

7. OVERALL ASSESSMENT:
   - Provide an overall assessment of the paper
   - Rate the significance and quality (1-10 scale)

PEER REVIEW:
""",
            input_variables=["title", "content"]
        )
    
    def generate_review(self, title: str, content: str) -> str:
        """
        Generate a peer-review style review
        
        Args:
            title: Paper title
            content: Paper content (can be summary or full text)
            
        Returns:
            Generated review text
        """
        if self.llm is None:
            return "Review generation not available. Please set OPENAI_API_KEY or install transformers for free models."
        
        try:
            # Limit content length more aggressively for free models
            max_content_length = 1000 if self.use_free_model else 2000
            limited_content = content[:max_content_length]
            prompt_text = self.review_prompt.format(title=title, content=limited_content)
            
            if self.review_chain:
                review = self.review_chain.run(title=title, content=limited_content)
                return review
            else:
                # Direct LLM call
                # For free models, limit prompt length
                if self.use_free_model and len(prompt_text) > 500:
                    prompt_text = prompt_text[:500] + "..."
                
                response = self.llm.invoke(prompt_text)
                if hasattr(response, 'content'):
                    return response.content
                return str(response)
        except Exception as e:
            print(f"Error generating review: {e}")
            # Return a basic template-based review if model fails
            return self._generate_template_review(title, content)
    
    def _generate_template_review(self, title: str, content: str) -> str:
        """Generate a basic template-based review when models are unavailable"""
        return f"""
PEER REVIEW FOR: {title}

1. CONTRIBUTIONS:
   This paper presents research in the field. Further analysis would require model access.

2. STRENGTHS:
   The paper structure appears well-organized based on the available sections.

3. WEAKNESSES AND LIMITATIONS:
   Full review requires language model access. Please set OPENAI_API_KEY or install transformers.

4. TECHNICAL QUALITY:
   Technical assessment requires model-based analysis.

5. CLARITY AND PRESENTATION:
   The paper appears to follow standard academic structure.

6. FUTURE DIRECTIONS:
   Future work directions would be identified through model-based analysis.

7. OVERALL ASSESSMENT:
   Complete assessment requires language model access.

NOTE: This is a template review. For full review generation, please:
- Set OPENAI_API_KEY in .env file (requires payment), OR
- Install transformers: pip install transformers torch (free, but requires more setup)
"""
    
    def generate_structured_review(self, paper_data: Dict) -> Dict[str, str]:
        """
        Generate structured review with separate components
        
        Args:
            paper_data: Dictionary containing paper information and summaries
            
        Returns:
            Dictionary with structured review components
        """
        title = paper_data.get('metadata', {}).get('title', 'Unknown Title')
        summary = paper_data.get('summary', {}).get('full_summary', '')
        sections = paper_data.get('processed', {}).get('sections', {})
        
        # Use full summary or combine sections for review
        if summary:
            content = summary
        else:
            # Combine key sections
            content_parts = []
            for section in ['abstract', 'introduction', 'methodology', 'results', 'conclusion']:
                if sections.get(section):
                    content_parts.append(f"{section.upper()}\n{sections[section]}")
            content = "\n\n".join(content_parts)
        
        # Generate full review
        full_review = self.generate_review(title, content)
        
        # Parse review into structured components (basic parsing)
        structured_review = self._parse_review(full_review)
        structured_review['full_review'] = full_review
        
        return structured_review
    
    def _parse_review(self, review_text: str) -> Dict[str, str]:
        """
        Parse review text into structured components
        
        Args:
            review_text: Full review text
            
        Returns:
            Dictionary with parsed components
        """
        structured = {
            'contributions': '',
            'strengths': '',
            'weaknesses': '',
            'technical_quality': '',
            'clarity': '',
            'future_directions': '',
            'overall_assessment': ''
        }
        
        # Simple parsing based on section headers
        sections = {
            'contributions': r'(?i)(?:1\.?\s*)?CONTRIBUTIONS?[:\s]*(.+?)(?=\n\s*\d\.|$)',
            'strengths': r'(?i)(?:2\.?\s*)?STRENGTHS?[:\s]*(.+?)(?=\n\s*\d\.|$)',
            'weaknesses': r'(?i)(?:3\.?\s*)?WEAKNESSES?[:\s]*(.+?)(?=\n\s*\d\.|$)',
            'technical_quality': r'(?i)(?:4\.?\s*)?TECHNICAL QUALITY[:\s]*(.+?)(?=\n\s*\d\.|$)',
            'clarity': r'(?i)(?:5\.?\s*)?CLARITY[:\s]*(.+?)(?=\n\s*\d\.|$)',
            'future_directions': r'(?i)(?:6\.?\s*)?FUTURE DIRECTIONS?[:\s]*(.+?)(?=\n\s*\d\.|$)',
            'overall_assessment': r'(?i)(?:7\.?\s*)?OVERALL ASSESSMENT[:\s]*(.+?)(?=\n\s*\d\.|$)'
        }
        
        import re
        for key, pattern in sections.items():
            match = re.search(pattern, review_text, re.DOTALL)
            if match:
                structured[key] = match.group(1).strip()
        
        return structured

