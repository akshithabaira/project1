"""
Research Paper Summarizer and Reviewer
A LangChain-based pipeline for automated scientific literature analysis
"""

__version__ = "1.0.0"

