"""
Agent-Based Pipeline Module
"""

from .agent_pipeline import ResearchPaperPipeline

__all__ = ['ResearchPaperPipeline']

