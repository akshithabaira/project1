"""
Agent-Based Pipeline Module
Orchestrates retrieval, processing, summarization, and review generation
"""

from typing import Dict, List, Optional
import os

# Try to import agent-related modules (optional, newer LangChain versions may not have these)
try:
    from langchain.agents import initialize_agent, AgentType
    from langchain.tools import Tool
    AGENT_AVAILABLE = True
except ImportError:
    # Newer LangChain versions may have different agent APIs
    AGENT_AVAILABLE = False

from langchain_openai import ChatOpenAI

from ..retrieval import PaperRetriever
from ..processing import TextProcessor
from ..summarization import Summarizer
from ..review import ReviewGenerator
from ..evaluation import EvaluationMetrics


class ResearchPaperPipeline:
    """
    End-to-end pipeline for processing research papers
    Orchestrates retrieval, summarization, and review generation
    """
    
    def __init__(self, 
                 summarizer_model: str = "openai",
                 review_model: str = "gpt-3.5-turbo",
                 max_results: int = 1,
                 use_free_models: bool = False):
        """
        Initialize the pipeline
        
        Args:
            summarizer_model: Model type for summarization ("openai", "bart", "pegasus")
            review_model: Model name for review generation
            max_results: Maximum number of papers to process per query
            use_free_models: If True, use free HuggingFace models instead of OpenAI (default: False)
        """
        self.max_results = max_results
        self.use_free_models = use_free_models
        
        # If use_free_models is True, override model choices
        if use_free_models:
            if summarizer_model == "openai":
                summarizer_model = "bart"  # Use free BART model
            if review_model == "gpt-3.5-turbo":
                review_model = "facebook/bart-large-cnn"  # Use free BART for reviews
            print("Using free models (no OpenAI API required)")
        
        # Initialize components
        self.retriever = PaperRetriever(max_results=max_results)
        self.processor = TextProcessor()
        self.summarizer = Summarizer(model_type=summarizer_model)
        self.review_generator = ReviewGenerator(model_name=review_model, use_free_model=use_free_models)
        self.evaluator = EvaluationMetrics()
        
        # Initialize agent (optional, for advanced orchestration)
        self.agent = None
        self._initialize_agent()
    
    def _initialize_agent(self):
        """Initialize LangChain agent for orchestration (optional)"""
        if not AGENT_AVAILABLE:
            # Agent API not available in this LangChain version
            return
        
        try:
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                return
            
            llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0)
            
            # Define tools for the agent
            tools = [
                Tool(
                    name="RetrievePapers",
                    func=lambda q: str(self.retriever.retrieve_papers(q)),
                    description="Retrieves research papers from arXiv by keywords"
                ),
                Tool(
                    name="ProcessPaper",
                    func=lambda d: str(self.processor.process_paper(d)),
                    description="Processes and segments a paper document"
                ),
                Tool(
                    name="SummarizePaper",
                    func=lambda p: str(self.summarizer.generate_summary(p)),
                    description="Generates summary of a processed paper"
                ),
                Tool(
                    name="GenerateReview",
                    func=lambda d: str(self.review_generator.generate_structured_review(d)),
                    description="Generates peer-review style feedback"
                )
            ]
            
            self.agent = initialize_agent(
                tools=tools,
                llm=llm,
                agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
                verbose=False
            )
        except Exception as e:
            # Silently fail - agent is optional
            pass
    
    def process_paper(self, 
                      query: str,
                      query_type: str = "keywords",
                      evaluate: bool = True) -> Dict:
        """
        Process a paper end-to-end: retrieve, summarize, and review
        
        Args:
            query: Search query (keywords, title, or author)
            query_type: Type of query ("keywords", "title", "author")
            evaluate: Whether to compute evaluation metrics
            
        Returns:
            Dictionary containing all results and metrics
        """
        # Step 1: Retrieve papers
        print(f"Retrieving papers for query: {query}")
        papers = self.retriever.retrieve_papers(query, query_type, self.max_results)
        
        if not papers:
            return {
                'error': 'No papers found for the given query',
                'query': query
            }
        
        results = []
        
        for paper_info in papers:
            document = paper_info['document']
            metadata = paper_info['metadata']
            
            print(f"Processing paper: {metadata.get('title', 'Unknown')}")
            
            # Step 2: Process paper
            processed = self.processor.process_paper(document)
            
            # Step 3: Generate summary
            print("Generating summary...")
            summary = self.summarizer.generate_summary(processed)
            
            # Step 4: Generate review
            print("Generating review...")
            paper_data = {
                'metadata': metadata,
                'summary': summary,
                'processed': processed
            }
            review = self.review_generator.generate_structured_review(paper_data)
            
            # Step 5: Evaluate (if reference available)
            metrics = {}
            if evaluate:
                print("Computing evaluation metrics...")
                # Use abstract as reference for summary evaluation
                abstract = processed['sections'].get('abstract', '')
                if abstract:
                    summary_metrics = self.evaluator.evaluate_summary(
                        generated_summary=summary.get('full_summary', ''),
                        abstract=abstract
                    )
                    metrics['summary_metrics'] = summary_metrics
            
            result = {
                'metadata': metadata,
                'processed': {
                    'sections': processed['sections'],
                    'num_chunks': len(processed['chunks'])
                },
                'summary': summary,
                'review': review,
                'metrics': metrics
            }
            
            results.append(result)
        
        return {
            'query': query,
            'num_papers': len(results),
            'results': results[0] if len(results) == 1 else results,
            'all_results': results
        }
    
    def process_multiple_papers(self, queries: List[str], 
                                query_type: str = "keywords") -> Dict:
        """
        Process multiple papers
        
        Args:
            queries: List of search queries
            query_type: Type of queries
            
        Returns:
            Dictionary with results for all papers
        """
        all_results = []
        
        for query in queries:
            result = self.process_paper(query, query_type, evaluate=True)
            all_results.append(result)
        
        return {
            'num_queries': len(queries),
            'results': all_results
        }
    
    def get_paper_info(self, query: str, query_type: str = "keywords") -> List[Dict]:
        """
        Get paper information without full processing
        
        Args:
            query: Search query
            query_type: Type of query
            
        Returns:
            List of paper metadata dictionaries
        """
        papers = self.retriever.retrieve_papers(query, query_type, self.max_results)
        return [paper['metadata'] for paper in papers]

