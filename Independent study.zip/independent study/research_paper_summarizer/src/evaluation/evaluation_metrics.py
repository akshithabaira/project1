"""
Evaluation Metrics Module
Implements ROUGE and BLEU metrics for evaluating summaries and reviews
"""

from typing import Dict, Optional
try:
    from rouge_score import rouge_scorer
    ROUGE_AVAILABLE = True
except ImportError:
    ROUGE_AVAILABLE = False

try:
    from nltk.translate.bleu_score import sentence_bleu, SmoothingFunction
    from nltk.tokenize import word_tokenize
    import nltk
    BLEU_AVAILABLE = True
    # Download required NLTK data
    try:
        nltk.data.find('tokenizers/punkt')
    except LookupError:
        nltk.download('punkt', quiet=True)
except ImportError:
    BLEU_AVAILABLE = False


class EvaluationMetrics:
    """
    Computes evaluation metrics (ROUGE, BLEU) for generated summaries
    """
    
    def __init__(self):
        """Initialize the evaluation metrics"""
        if ROUGE_AVAILABLE:
            self.rouge_scorer = rouge_scorer.RougeScorer(
                ['rouge1', 'rouge2', 'rougeL'],
                use_stemmer=True
            )
        else:
            self.rouge_scorer = None
            print("Warning: rouge-score not available. ROUGE metrics will not be computed.")
    
    def compute_rouge_scores(self, generated_text: str, reference_text: str) -> Dict[str, float]:
        """
        Compute ROUGE scores between generated and reference text
        
        Args:
            generated_text: Generated summary/review text
            reference_text: Reference text (e.g., abstract)
            
        Returns:
            Dictionary with ROUGE-1, ROUGE-2, and ROUGE-L F1 scores
        """
        if not ROUGE_AVAILABLE or not self.rouge_scorer:
            return {
                'rouge1': 0.0,
                'rouge2': 0.0,
                'rougeL': 0.0
            }
        
        if not generated_text or not reference_text:
            return {
                'rouge1': 0.0,
                'rouge2': 0.0,
                'rougeL': 0.0
            }
        
        try:
            scores = self.rouge_scorer.score(reference_text, generated_text)
            return {
                'rouge1': scores['rouge1'].fmeasure,
                'rouge2': scores['rouge2'].fmeasure,
                'rougeL': scores['rougeL'].fmeasure
            }
        except Exception as e:
            print(f"Error computing ROUGE scores: {e}")
            return {
                'rouge1': 0.0,
                'rouge2': 0.0,
                'rougeL': 0.0
            }
    
    def compute_bleu_score(self, generated_text: str, reference_text: str) -> float:
        """
        Compute BLEU score between generated and reference text
        
        Args:
            generated_text: Generated summary/review text
            reference_text: Reference text
            
        Returns:
            BLEU score (0-1)
        """
        if not BLEU_AVAILABLE:
            return 0.0
        
        if not generated_text or not reference_text:
            return 0.0
        
        try:
            # Tokenize texts
            reference_tokens = word_tokenize(reference_text.lower())
            generated_tokens = word_tokenize(generated_text.lower())
            
            # Use smoothing function to handle cases with no n-gram matches
            smoothing = SmoothingFunction().method1
            
            # Compute BLEU score
            score = sentence_bleu(
                [reference_tokens],
                generated_tokens,
                smoothing_function=smoothing
            )
            
            return score
        except Exception as e:
            print(f"Error computing BLEU score: {e}")
            return 0.0
    
    def evaluate_summary(self, 
                         generated_summary: str, 
                         abstract: Optional[str] = None,
                         reference_summary: Optional[str] = None) -> Dict[str, float]:
        """
        Evaluate a generated summary using multiple metrics
        
        Args:
            generated_summary: The generated summary
            abstract: Paper abstract (used as reference if reference_summary not provided)
            reference_summary: Reference summary (optional, overrides abstract)
            
        Returns:
            Dictionary with all evaluation metrics
        """
        reference = reference_summary or abstract or ""
        
        if not reference:
            return {
                'rouge1': 0.0,
                'rouge2': 0.0,
                'rougeL': 0.0,
                'bleu': 0.0
            }
        
        rouge_scores = self.compute_rouge_scores(generated_summary, reference)
        bleu_score = self.compute_bleu_score(generated_summary, reference)
        
        return {
            **rouge_scores,
            'bleu': bleu_score
        }
    
    def evaluate_review(self, generated_review: str, reference_review: Optional[str] = None) -> Dict[str, float]:
        """
        Evaluate a generated review (if reference available)
        
        Args:
            generated_review: Generated review text
            reference_review: Reference review (optional)
            
        Returns:
            Dictionary with evaluation metrics
        """
        if not reference_review:
            # Without reference, we can't compute metrics
            return {
                'rouge1': 0.0,
                'rouge2': 0.0,
                'rougeL': 0.0,
                'bleu': 0.0
            }
        
        rouge_scores = self.compute_rouge_scores(generated_review, reference_review)
        bleu_score = self.compute_bleu_score(generated_review, reference_review)
        
        return {
            **rouge_scores,
            'bleu': bleu_score
        }
    
    def compute_all_metrics(self, 
                           generated_summary: str,
                           generated_review: str,
                           abstract: Optional[str] = None,
                           reference_summary: Optional[str] = None,
                           reference_review: Optional[str] = None) -> Dict[str, Dict[str, float]]:
        """
        Compute all evaluation metrics for both summary and review
        
        Args:
            generated_summary: Generated summary
            generated_review: Generated review
            abstract: Paper abstract
            reference_summary: Reference summary (optional)
            reference_review: Reference review (optional)
            
        Returns:
            Dictionary with summary_metrics and review_metrics
        """
        summary_metrics = self.evaluate_summary(
            generated_summary,
            abstract=abstract,
            reference_summary=reference_summary
        )
        
        review_metrics = self.evaluate_review(
            generated_review,
            reference_review=reference_review
        )
        
        return {
            'summary_metrics': summary_metrics,
            'review_metrics': review_metrics
        }

