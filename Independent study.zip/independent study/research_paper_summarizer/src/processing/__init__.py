"""
Text Processing Module
"""

from .text_processor import TextProcessor

__all__ = ['TextProcessor']

