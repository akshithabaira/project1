"""
Text Processing Module
Segments research papers into structured sections and processes text
"""

import re
from typing import List, Dict, Optional
try:
    from langchain_text_splitters import RecursiveCharacterTextSplitter
except ImportError:
    # Fallback for older LangChain versions
    from langchain.text_splitter import RecursiveCharacterTextSplitter
try:
    from langchain_core.documents import Document
except ImportError:
    # Fallback for older LangChain versions
    from langchain.schema import Document


class TextProcessor:
    """
    Processes and segments research papers into structured sections
    """
    
    def __init__(self, chunk_size: int = 2000, chunk_overlap: int = 200):
        """
        Initialize the text processor
        
        Args:
            chunk_size: Size of text chunks for processing
            chunk_overlap: Overlap between chunks
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            length_function=len,
        )
    
    def extract_sections(self, text: str) -> Dict[str, str]:
        """
        Extract structured sections from a research paper
        
        Args:
            text: Full text of the paper
            
        Returns:
            Dictionary mapping section names to their content
        """
        sections = {
            'abstract': '',
            'introduction': '',
            'methodology': '',
            'results': '',
            'conclusion': '',
            'full_text': text
        }
        
        # Common section headers patterns
        section_patterns = {
            'abstract': r'(?i)(?:^|\n)\s*(?:abstract|summary)\s*\n',
            'introduction': r'(?i)(?:^|\n)\s*(?:1\.?\s*)?introduction\s*\n',
            'methodology': r'(?i)(?:^|\n)\s*(?:2\.?\s*)?(?:methodology|methods|approach|method)\s*\n',
            'results': r'(?i)(?:^|\n)\s*(?:3\.?\s*)?(?:results|experiments|experimental\s+results)\s*\n',
            'conclusion': r'(?i)(?:^|\n)\s*(?:conclusion|conclusions|discussion|future\s+work)\s*\n'
        }
        
        # Find section boundaries
        section_indices = {}
        for section_name, pattern in section_patterns.items():
            match = re.search(pattern, text)
            if match:
                section_indices[section_name] = match.start()
        
        # Extract sections based on boundaries
        sorted_sections = sorted(section_indices.items(), key=lambda x: x[1])
        
        for i, (section_name, start_idx) in enumerate(sorted_sections):
            if i + 1 < len(sorted_sections):
                end_idx = sorted_sections[i + 1][1]
                sections[section_name] = text[start_idx:end_idx].strip()
            else:
                sections[section_name] = text[start_idx:].strip()
        
        # If abstract not found, try to extract from beginning
        if not sections['abstract']:
            # Look for abstract in first few paragraphs
            first_paragraphs = text[:2000]
            abstract_match = re.search(r'(?i)abstract[:\s]*(.+?)(?:\n\s*\n|\n\s*[1-9]\.)', 
                                       first_paragraphs, re.DOTALL)
            if abstract_match:
                sections['abstract'] = abstract_match.group(1).strip()
        
        return sections
    
    def chunk_text(self, text: str) -> List[str]:
        """
        Split text into chunks for processing
        
        Args:
            text: Text to chunk
            
        Returns:
            List of text chunks
        """
        chunks = self.text_splitter.split_text(text)
        return chunks
    
    def chunk_document(self, document: Document) -> List[Document]:
        """
        Split a document into smaller chunks
        
        Args:
            document: LangChain Document object
            
        Returns:
            List of Document chunks
        """
        chunks = self.text_splitter.split_documents([document])
        return chunks
    
    def clean_text(self, text: str) -> str:
        """
        Clean and normalize text
        
        Args:
            text: Raw text
            
        Returns:
            Cleaned text
        """
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text)
        # Remove special characters but keep punctuation
        text = re.sub(r'[^\w\s\.\,\;\:\!\?\-\(\)\[\]\"\']', '', text)
        return text.strip()
    
    def process_paper(self, document: Document) -> Dict:
        """
        Process a complete paper document
        
        Args:
            document: LangChain Document object
            
        Returns:
            Dictionary containing processed sections and chunks
        """
        text = document.page_content
        
        # Extract sections
        sections = self.extract_sections(text)
        
        # Chunk the full text
        chunks = self.chunk_text(text)
        
        # Chunk each section
        section_chunks = {}
        for section_name, section_text in sections.items():
            if section_text:
                section_chunks[section_name] = self.chunk_text(section_text)
        
        return {
            'sections': sections,
            'chunks': chunks,
            'section_chunks': section_chunks,
            'metadata': document.metadata
        }

