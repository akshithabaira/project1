"""
Summarization Module
"""

from .summarizer import Summarizer

__all__ = ['Summarizer']

