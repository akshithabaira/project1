"""
Summarization Module
Implements abstractive summarization using LangChain chains and transformer models
"""

import os
from typing import List, Dict, Optional

# Try to import chains - may vary by LangChain version
try:
    from langchain.chains.summarize import load_summarize_chain
    CHAINS_AVAILABLE = True
except ImportError:
    try:
        # Try langchain-classic
        from langchain_classic.chains.summarize import load_summarize_chain
        CHAINS_AVAILABLE = True
    except ImportError:
        CHAINS_AVAILABLE = False

try:
    from langchain_core.documents import Document
    from langchain_core.prompts import PromptTemplate
except ImportError:
    # Fallback for older LangChain versions
    try:
        from langchain.schema import Document
        from langchain.prompts import PromptTemplate
    except ImportError:
        from langchain_core.documents import Document
        from langchain_core.prompts import PromptTemplate

from langchain_openai import ChatOpenAI
# Try new langchain-huggingface first, fallback to old import
try:
    from langchain_huggingface import HuggingFacePipeline
    HUGGINGFACE_PIPELINE_AVAILABLE = True
except ImportError:
    try:
        from langchain_community.llms import HuggingFacePipeline
        HUGGINGFACE_PIPELINE_AVAILABLE = True
    except ImportError:
        HuggingFacePipeline = None
        HUGGINGFACE_PIPELINE_AVAILABLE = False

try:
    from transformers import pipeline, AutoTokenizer, AutoModelForSeq2SeqLM
    import torch
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False


class Summarizer:
    """
    Generates abstractive summaries using map-reduce approach
    Supports multiple models: GPT, BART, PEGASUS
    """
    
    def __init__(self, model_type: str = "openai", model_name: Optional[str] = None):
        """
        Initialize the summarizer
        
        Args:
            model_type: Type of model ("openai", "bart", "pegasus")
            model_name: Specific model name/identifier
        """
        self.model_type = model_type
        self.model_name = model_name or self._get_default_model(model_type)
        self.llm = self._initialize_llm()
        self.map_prompt = self._create_map_prompt()
        self.combine_prompt = self._create_combine_prompt()
    
    def _get_default_model(self, model_type: str) -> str:
        """Get default model name based on type"""
        defaults = {
            "openai": "gpt-3.5-turbo",
            "bart": "facebook/bart-large-cnn",
            "pegasus": "google/pegasus-xsum"
        }
        return defaults.get(model_type, "gpt-3.5-turbo")
    
    def _initialize_llm(self):
        """Initialize the language model"""
        if self.model_type == "openai":
            api_key = os.getenv("OPENAI_API_KEY")
            if not api_key:
                print("Warning: OPENAI_API_KEY not found. Falling back to free BART model...")
                # Fallback to BART
                return self._initialize_huggingface_model("facebook/bart-large-cnn")
            try:
                return ChatOpenAI(
                    model=self.model_name,
                    temperature=0.3,
                    max_tokens=1000
                )
            except Exception as e:
                print(f"Error initializing OpenAI: {e}. Falling back to free BART model...")
                return self._initialize_huggingface_model("facebook/bart-large-cnn")
        elif self.model_type in ["bart", "pegasus"]:
            # Use HuggingFace models
            return self._initialize_huggingface_model(self.model_name)
        else:
            raise ValueError(f"Unsupported model type: {self.model_type}")
    
    def _initialize_huggingface_model(self, model_name: str):
        """Initialize HuggingFace model"""
        if not TRANSFORMERS_AVAILABLE or not HUGGINGFACE_PIPELINE_AVAILABLE:
            print("Error: Transformers or HuggingFacePipeline not available.")
            print("Please install: pip install transformers torch langchain-huggingface")
            raise ValueError("HuggingFace models require transformers package. Install with: pip install transformers torch langchain-huggingface")
        
        try:
            print(f"Loading free HuggingFace model: {model_name} (this may take a minute on first run)...")
            tokenizer = AutoTokenizer.from_pretrained(model_name)
            model = AutoModelForSeq2SeqLM.from_pretrained(model_name)
            
            # Get model's max length
            max_model_length = getattr(tokenizer, 'model_max_length', 1024)
            # Use a safe chunk size (leave room for generation)
            safe_max_length = min(512, max_model_length - 100)
            
            hf_pipeline = pipeline(
                "summarization",
                model=model,
                tokenizer=tokenizer,
                max_length=safe_max_length,
                min_length=50,  # Reduced from 100 to avoid issues
                device=0 if torch.cuda.is_available() else -1,
                truncation=True  # Enable truncation
            )
            
            return HuggingFacePipeline(pipeline=hf_pipeline)
        except Exception as e:
            print(f"Error loading HuggingFace model {model_name}: {e}")
            print("Please ensure transformers and torch are installed: pip install transformers torch langchain-huggingface")
            raise
    
    def _create_map_prompt(self) -> PromptTemplate:
        """Create prompt template for map step"""
        return PromptTemplate(
            template="""
Write a concise summary of the following section from a research paper:

{text}

CONCISE SUMMARY:""",
            input_variables=["text"]
        )
    
    def _create_combine_prompt(self) -> PromptTemplate:
        """Create prompt template for combine step"""
        return PromptTemplate(
            template="""
The following are summaries of different sections from a research paper:

{text}

Write a comprehensive summary that combines all these summaries into a coherent, well-structured summary of the entire paper. 
Focus on the main contributions, methodology, key findings, and conclusions.

COMPREHENSIVE SUMMARY:""",
            input_variables=["text"]
        )
    
    def summarize_document(self, document: Document) -> str:
        """
        Summarize a single document
        
        Args:
            document: LangChain Document object
            
        Returns:
            Generated summary string
        """
        # Limit document size to avoid token errors
        max_chars = 1500 if self.model_type in ["bart", "pegasus"] else 4000
        doc_text = document.page_content[:max_chars]
        doc = Document(page_content=doc_text)
        
        if not CHAINS_AVAILABLE:
            # Fallback: direct LLM call
            try:
                prompt_text = self.combine_prompt.format(text=doc_text)
                response = self.llm.invoke(prompt_text)
                if hasattr(response, 'content'):
                    return response.content
                return str(response)
            except Exception as e:
                print(f"Error in summarization: {e}")
                return ""
        
        try:
            chain = load_summarize_chain(
                llm=self.llm,
                chain_type="stuff",
                prompt=self.combine_prompt
            )
            summary = chain.run([doc])
            return summary
        except Exception as e:
            print(f"Error in summarization: {e}")
            # Fallback to direct LLM call
            try:
                prompt_text = self.combine_prompt.format(text=doc_text)
                response = self.llm.invoke(prompt_text)
                if hasattr(response, 'content'):
                    return response.content
                return str(response)
            except:
                return ""
    
    def summarize_chunks(self, chunks: List[Document]) -> str:
        """
        Summarize multiple chunks using map-reduce approach
        
        Args:
            chunks: List of Document chunks
            
        Returns:
            Combined summary
        """
        if not chunks:
            return ""
        
        if len(chunks) == 1:
            return self.summarize_document(chunks[0])
        
        # For HuggingFace models, use manual chunk-by-chunk approach to avoid token limits
        if self.model_type in ["bart", "pegasus"]:
            summaries = []
            # Process chunks one at a time with size limits
            for chunk in chunks[:10]:  # Limit chunks to avoid memory issues
                try:
                    # Limit chunk size to avoid token errors
                    chunk_text = chunk.page_content[:2000]  # Limit to ~2000 chars
                    chunk_doc = Document(page_content=chunk_text)
                    chunk_summary = self.summarize_document(chunk_doc)
                    if chunk_summary and len(chunk_summary.strip()) > 20:
                        summaries.append(chunk_summary)
                except Exception as e:
                    print(f"Error summarizing chunk: {e}")
                    continue
            
            if summaries:
                # Combine summaries into final summary
                if len(summaries) == 1:
                    return summaries[0]
                # Combine first few summaries
                combined_text = "\n\n".join(summaries[:5])  # Limit to 5 summaries
                if len(combined_text) > 2000:
                    combined_text = combined_text[:2000]
                combined_doc = Document(page_content=combined_text)
                return self.summarize_document(combined_doc)
            return ""
        
        if not CHAINS_AVAILABLE:
            # Fallback: summarize each chunk and combine manually
            summaries = []
            for chunk in chunks[:5]:  # Limit to first 5 chunks to avoid token limits
                try:
                    chunk_text = chunk.page_content[:2000]
                    chunk_doc = Document(page_content=chunk_text)
                    chunk_summary = self.summarize_document(chunk_doc)
                    if chunk_summary:
                        summaries.append(chunk_summary)
                except Exception as e:
                    print(f"Error summarizing chunk: {e}")
                    continue
            
            if summaries:
                # Combine summaries
                combined_text = "\n\n".join(summaries)
                combined_doc = Document(page_content=combined_text)
                return self.summarize_document(combined_doc)
            return ""
        
        try:
            # Create map-reduce chain
            chain = load_summarize_chain(
                llm=self.llm,
                chain_type="map_reduce",
                map_prompt=self.map_prompt,
                combine_prompt=self.combine_prompt,
                verbose=False
            )
            
            summary = chain.run(chunks)
            return summary
        except Exception as e:
            print(f"Error in map-reduce summarization: {e}")
            # Fallback to simple summarization
            if chunks:
                chunk_text = chunks[0].page_content[:2000]
                chunk_doc = Document(page_content=chunk_text)
                return self.summarize_document(chunk_doc)
            return ""
    
    def summarize_sections(self, sections: Dict[str, str]) -> Dict[str, str]:
        """
        Summarize each section of a paper
        
        Args:
            sections: Dictionary mapping section names to content
            
        Returns:
            Dictionary mapping section names to summaries
        """
        summaries = {}
        
        for section_name, section_text in sections.items():
            if section_text and section_name != 'full_text':
                doc = Document(page_content=section_text)
                summary = self.summarize_document(doc)
                summaries[section_name] = summary
        
        return summaries
    
    def generate_summary(self, processed_paper: Dict) -> Dict[str, str]:
        """
        Generate comprehensive summary from processed paper
        
        Args:
            processed_paper: Dictionary from TextProcessor.process_paper()
            
        Returns:
            Dictionary containing various summaries
        """
        chunks = [Document(page_content=chunk) for chunk in processed_paper['chunks']]
        sections = processed_paper['sections']
        
        # Generate full document summary
        full_summary = self.summarize_chunks(chunks)
        
        # Generate section summaries
        section_summaries = self.summarize_sections(sections)
        
        # Generate abstract summary if available
        abstract_summary = ""
        if sections.get('abstract'):
            abstract_doc = Document(page_content=sections['abstract'])
            abstract_summary = self.summarize_document(abstract_doc)
        
        return {
            'full_summary': full_summary,
            'section_summaries': section_summaries,
            'abstract_summary': abstract_summary,
            'sections_covered': list(section_summaries.keys())
        }

