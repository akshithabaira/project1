"""
Paper Retrieval Module
Uses LangChain's ArxivLoader to fetch scientific papers from arXiv
"""

from typing import List, Dict, Optional
from langchain_community.document_loaders import ArxivLoader
try:
    from langchain_core.documents import Document
except ImportError:
    # Fallback for older LangChain versions
    from langchain.schema import Document
import arxiv


class PaperRetriever:
    """
    Retrieves research papers from arXiv using LangChain's ArxivLoader
    """
    
    def __init__(self, max_results: int = 5):
        """
        Initialize the paper retriever
        
        Args:
            max_results: Maximum number of papers to retrieve per query
        """
        self.max_results = max_results
    
    def search_by_keywords(self, keywords: str, max_results: Optional[int] = None) -> List[Document]:
        """
        Search for papers by keywords
        
        Args:
            keywords: Search keywords (e.g., "transformer attention mechanism")
            max_results: Maximum number of results (overrides instance default)
            
        Returns:
            List of Document objects containing paper content
        """
        max_results = max_results or self.max_results
        
        try:
            loader = ArxivLoader(query=keywords, load_max_docs=max_results)
            documents = loader.load()
            return documents
        except Exception as e:
            print(f"Error retrieving papers: {e}")
            return []
    
    def search_by_title(self, title: str) -> List[Document]:
        """
        Search for a paper by exact title
        
        Args:
            title: Paper title
            
        Returns:
            List of Document objects (typically one paper)
        """
        try:
            loader = ArxivLoader(query=f"ti:{title}", load_max_docs=1)
            documents = loader.load()
            return documents
        except Exception as e:
            print(f"Error retrieving paper by title: {e}")
            return []
    
    def search_by_author(self, author: str, max_results: Optional[int] = None) -> List[Document]:
        """
        Search for papers by author name
        
        Args:
            author: Author name
            max_results: Maximum number of results
            
        Returns:
            List of Document objects
        """
        max_results = max_results or self.max_results
        
        try:
            loader = ArxivLoader(query=f"au:{author}", load_max_docs=max_results)
            documents = loader.load()
            return documents
        except Exception as e:
            print(f"Error retrieving papers by author: {e}")
            return []
    
    def get_paper_metadata(self, document: Document) -> Dict:
        """
        Extract metadata from a retrieved document
        
        Args:
            document: LangChain Document object
            
        Returns:
            Dictionary containing paper metadata
        """
        metadata = document.metadata.copy()
        
        # Extract additional information from the document
        content = document.page_content
        
        # Try to extract title and authors from content
        lines = content.split('\n')
        title = metadata.get('Title', 'Unknown')
        authors = metadata.get('Authors', 'Unknown')
        
        return {
            'title': title,
            'authors': authors,
            'published': metadata.get('Published', 'Unknown'),
            'arxiv_id': metadata.get('Entry ID', 'Unknown'),
            'summary': metadata.get('Summary', ''),
            'categories': metadata.get('Categories', ''),
            'url': metadata.get('Entry ID', '').replace('arxiv:', 'https://arxiv.org/abs/') if metadata.get('Entry ID') else ''
        }
    
    def retrieve_papers(self, query: str, query_type: str = "keywords", 
                       max_results: Optional[int] = None) -> List[Dict]:
        """
        Unified interface for retrieving papers
        
        Args:
            query: Search query
            query_type: Type of query ("keywords", "title", "author")
            max_results: Maximum number of results
            
        Returns:
            List of dictionaries containing paper documents and metadata
        """
        max_results = max_results or self.max_results
        
        if query_type == "title":
            documents = self.search_by_title(query)
        elif query_type == "author":
            documents = self.search_by_author(query, max_results)
        else:
            documents = self.search_by_keywords(query, max_results)
        
        results = []
        for doc in documents:
            metadata = self.get_paper_metadata(doc)
            results.append({
                'document': doc,
                'metadata': metadata
            })
        
        return results

