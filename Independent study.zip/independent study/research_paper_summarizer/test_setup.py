"""
Quick test script to verify the installation and setup
"""

import sys

def test_imports():
    """Test if all required modules can be imported"""
    print("=" * 60)
    print("Testing Imports...")
    print("=" * 60)
    
    tests_passed = 0
    tests_failed = 0
    
    # Test basic imports
    try:
        import langchain
        print("✓ langchain imported successfully")
        tests_passed += 1
    except ImportError as e:
        print(f"✗ langchain import failed: {e}")
        tests_failed += 1
    
    try:
        from langchain_community.document_loaders import ArxivLoader
        print("✓ langchain_community imported successfully")
        tests_passed += 1
    except ImportError as e:
        print(f"✗ langchain_community import failed: {e}")
        tests_failed += 1
    
    try:
        from langchain_openai import ChatOpenAI
        print("✓ langchain_openai imported successfully")
        tests_passed += 1
    except ImportError as e:
        print(f"✗ langchain_openai import failed: {e}")
        tests_failed += 1
    
    try:
        import arxiv
        print("✓ arxiv imported successfully")
        tests_passed += 1
    except ImportError as e:
        print(f"✗ arxiv import failed: {e}")
        tests_failed += 1
    
    try:
        import nltk
        print("✓ nltk imported successfully")
        tests_passed += 1
    except ImportError as e:
        print(f"✗ nltk import failed: {e}")
        tests_failed += 1
    
    try:
        from rouge_score import rouge_scorer
        print("✓ rouge-score imported successfully")
        tests_passed += 1
    except ImportError as e:
        print(f"✗ rouge-score import failed: {e}")
        tests_failed += 1
    
    try:
        from dotenv import load_dotenv
        print("✓ python-dotenv imported successfully")
        tests_passed += 1
    except ImportError as e:
        print(f"✗ python-dotenv import failed: {e}")
        tests_failed += 1
    
    # Test project imports
    print("\n" + "=" * 60)
    print("Testing Project Modules...")
    print("=" * 60)
    
    try:
        from src.retrieval import PaperRetriever
        print("✓ PaperRetriever imported successfully")
        tests_passed += 1
    except ImportError as e:
        print(f"✗ PaperRetriever import failed: {e}")
        tests_failed += 1
    
    try:
        from src.processing import TextProcessor
        print("✓ TextProcessor imported successfully")
        tests_passed += 1
    except ImportError as e:
        print(f"✗ TextProcessor import failed: {e}")
        tests_failed += 1
    
    try:
        from src.summarization import Summarizer
        print("✓ Summarizer imported successfully")
        tests_passed += 1
    except ImportError as e:
        print(f"✗ Summarizer import failed: {e}")
        tests_failed += 1
    
    try:
        from src.review import ReviewGenerator
        print("✓ ReviewGenerator imported successfully")
        tests_passed += 1
    except ImportError as e:
        print(f"✗ ReviewGenerator import failed: {e}")
        tests_failed += 1
    
    try:
        from src.evaluation import EvaluationMetrics
        print("✓ EvaluationMetrics imported successfully")
        tests_passed += 1
    except ImportError as e:
        print(f"✗ EvaluationMetrics import failed: {e}")
        tests_failed += 1
    
    try:
        from src.pipeline.agent_pipeline import ResearchPaperPipeline
        print("✓ ResearchPaperPipeline imported successfully")
        tests_passed += 1
    except ImportError as e:
        print(f"✗ ResearchPaperPipeline import failed: {e}")
        tests_failed += 1
    
    # Test environment variables
    print("\n" + "=" * 60)
    print("Testing Environment Setup...")
    print("=" * 60)
    
    import os
    from dotenv import load_dotenv
    load_dotenv()
    
    api_key = os.getenv("OPENAI_API_KEY")
    if api_key and api_key != "your_openai_api_key_here":
        print("✓ OPENAI_API_KEY found in environment")
        tests_passed += 1
    else:
        print("⚠ OPENAI_API_KEY not found or not set")
        print("  Please create a .env file with: OPENAI_API_KEY=your_key")
        tests_failed += 1
    
    # Summary
    print("\n" + "=" * 60)
    print("Test Summary")
    print("=" * 60)
    print(f"✓ Passed: {tests_passed}")
    print(f"✗ Failed: {tests_failed}")
    print(f"Total: {tests_passed + tests_failed}")
    
    if tests_failed == 0:
        print("\n🎉 All tests passed! Your setup is ready.")
        return True
    else:
        print("\n⚠ Some tests failed. Please check the errors above.")
        return False


def test_basic_functionality():
    """Test basic functionality without API calls"""
    print("\n" + "=" * 60)
    print("Testing Basic Functionality...")
    print("=" * 60)
    
    try:
        from src.processing import TextProcessor
        processor = TextProcessor()
        print("✓ TextProcessor initialized")
        
        # Test text processing
        test_text = "Abstract\nThis is a test abstract.\n\n1. Introduction\nThis is introduction."
        sections = processor.extract_sections(test_text)
        if sections:
            print("✓ Section extraction works")
        else:
            print("⚠ Section extraction returned empty")
        
        from src.evaluation import EvaluationMetrics
        evaluator = EvaluationMetrics()
        print("✓ EvaluationMetrics initialized")
        
        # Test metrics
        score = evaluator.compute_rouge_scores("test text", "test text")
        if score:
            print("✓ ROUGE score computation works")
        
        print("\n✓ Basic functionality tests passed!")
        return True
    except Exception as e:
        print(f"✗ Basic functionality test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("Research Paper Summarizer - Setup Test")
    print("=" * 60 + "\n")
    
    imports_ok = test_imports()
    
    if imports_ok:
        functionality_ok = test_basic_functionality()
        
        if functionality_ok:
            print("\n" + "=" * 60)
            print("✅ ALL TESTS PASSED!")
            print("=" * 60)
            print("\nYou can now run the main application:")
            print('  python main.py --query "machine learning"')
        else:
            print("\n⚠ Some functionality tests failed.")
    else:
        print("\n⚠ Please fix the import errors before proceeding.")



