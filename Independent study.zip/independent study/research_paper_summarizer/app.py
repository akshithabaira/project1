"""
Streamlit UI for Research Paper Summarizer and Reviewer
Provides a web-based interface for all terminal functionality
"""

import streamlit as st
import json
import os
import time
from dotenv import load_dotenv
from src.pipeline.agent_pipeline import ResearchPaperPipeline

# Load environment variables
load_dotenv()

# Page configuration
st.set_page_config(
    page_title="Research Paper Summarizer",
    page_icon="📄",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
    <style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 2rem;
    }
    .paper-card {
        background-color: #f0f2f6;
        padding: 1.5rem;
        border-radius: 10px;
        margin: 1rem 0;
        border-left: 4px solid #1f77b4;
    }
    .metric-box {
        background-color: #e8f4f8;
        padding: 1rem;
        border-radius: 5px;
        text-align: center;
        margin: 0.5rem;
    }
    .stProgress > div > div > div {
        background-color: #1f77b4;
    }
    </style>
""", unsafe_allow_html=True)

# Initialize session state
if 'results' not in st.session_state:
    st.session_state.results = None
if 'pipeline' not in st.session_state:
    st.session_state.pipeline = None


def format_metadata(metadata):
    """Format paper metadata for display"""
    return {
        "Title": metadata.get('title', 'Unknown'),
        "Authors": metadata.get('authors', 'Unknown'),
        "Published": metadata.get('published', 'Unknown'),
        "arXiv ID": metadata.get('arxiv_id', 'Unknown'),
        "URL": metadata.get('url', 'N/A')
    }


def display_results(result):
    """Display analysis results in the UI"""
    if 'error' in result:
        st.error(f"❌ Error: {result['error']}")
        return
    
    # Get results
    if 'all_results' in result:
        results = result['all_results']
    elif 'results' in result:
        results = [result['results']] if isinstance(result['results'], dict) else result['results']
    else:
        results = []
    
    st.success(f"✅ Successfully processed {len(results)} paper(s)")
    
    # Display each paper's results
    for idx, paper_result in enumerate(results, 1):
        st.markdown(f"---")
        st.markdown(f"### 📄 Paper {idx}")
        
        # Metadata
        metadata = paper_result.get('metadata', {})
        formatted_metadata = format_metadata(metadata)
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.markdown("#### Paper Information")
            for key, value in formatted_metadata.items():
                if key == "URL" and value != "N/A":
                    st.markdown(f"**{key}:** [{value}]({value})")
                else:
                    st.markdown(f"**{key}:** {value}")
        
        with col2:
            # Metrics display
            metrics = paper_result.get('metrics', {})
            if metrics.get('summary_metrics'):
                st.markdown("#### Evaluation Metrics")
                summary_metrics = metrics['summary_metrics']
                
                metric_cols = st.columns(4)
                with metric_cols[0]:
                    st.metric("ROUGE-1", f"{summary_metrics.get('rouge1', 0):.3f}")
                with metric_cols[1]:
                    st.metric("ROUGE-2", f"{summary_metrics.get('rouge2', 0):.3f}")
                with metric_cols[2]:
                    st.metric("ROUGE-L", f"{summary_metrics.get('rougeL', 0):.3f}")
                with metric_cols[3]:
                    st.metric("BLEU", f"{summary_metrics.get('bleu', 0):.3f}")
        
        # Summary
        summary = paper_result.get('summary', {})
        if summary.get('full_summary'):
            with st.expander("📝 Summary", expanded=True):
                st.write(summary['full_summary'])
        
        # Section Summaries (if verbose)
        if summary.get('section_summaries'):
            with st.expander("📑 Section Summaries"):
                for section, section_summary in summary['section_summaries'].items():
                    st.markdown(f"**{section.upper()}:**")
                    st.write(section_summary)
                    st.markdown("---")
        
        # Review
        review = paper_result.get('review', {})
        if review.get('full_review'):
            with st.expander("🔍 Peer Review", expanded=True):
                st.write(review['full_review'])
        
        # Structured Review Components
        if review:
            review_components = {k: v for k, v in review.items() 
                              if k != 'full_review' and v}
            if review_components:
                with st.expander("📊 Structured Review Components"):
                    for key, value in review_components.items():
                        st.markdown(f"**{key.upper().replace('_', ' ')}:**")
                        st.write(value)
                        st.markdown("---")


def save_results_to_file(result, filename):
    """Save results to JSON file"""
    def convert_to_serializable(obj):
        if hasattr(obj, 'page_content'):
            return obj.page_content
        if isinstance(obj, dict):
            return {k: convert_to_serializable(v) for k, v in obj.items()}
        if isinstance(obj, list):
            return [convert_to_serializable(item) for item in obj]
        return obj
    
    serializable_result = convert_to_serializable(result)
    
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(serializable_result, f, indent=2, ensure_ascii=False)
    
    return filename


def main():
    # Header
    st.markdown('<div class="main-header">📄 Research Paper Summarizer & Reviewer</div>', 
                unsafe_allow_html=True)
    st.markdown("---")
    
    # Sidebar for configuration
    with st.sidebar:
        st.header("⚙️ Configuration")
        
        # Query input
        query = st.text_input(
            "Search Query",
            placeholder="Enter keywords, title, or author name",
            help="Enter your search query here"
        )
        
        query_type = st.selectbox(
            "Query Type",
            options=['keywords', 'title', 'author'],
            index=0,
            help="Select the type of search query"
        )
        
        # Model selection
        st.subheader("Model Settings")
        
        use_free_models = st.checkbox(
            "Use Free Models (No API Key Required)",
            value=not bool(os.getenv("OPENAI_API_KEY")),
            help="Use free HuggingFace models instead of OpenAI"
        )
        
        if not use_free_models:
            if not os.getenv("OPENAI_API_KEY"):
                st.warning("⚠️ OPENAI_API_KEY not found. Using free models.")
                use_free_models = True
        
        summarizer_model = st.selectbox(
            "Summarizer Model",
            options=['openai', 'bart', 'pegasus'],
            index=0 if not use_free_models else 1,
            disabled=use_free_models,
            help="Model for summarization"
        )
        
        review_model = st.text_input(
            "Review Model",
            value="gpt-3.5-turbo",
            disabled=use_free_models,
            help="Model for review generation"
        )
        
        # Processing options
        st.subheader("Processing Options")
        
        max_results = st.slider(
            "Max Results",
            min_value=1,
            max_value=5,
            value=1,
            help="Maximum number of papers to process"
        )
        
        evaluate = st.checkbox(
            "Compute Evaluation Metrics",
            value=True,
            help="Calculate ROUGE and BLEU scores"
        )
        
        verbose = st.checkbox(
            "Verbose Output",
            value=False,
            help="Show detailed output including section summaries"
        )
        
        st.markdown("---")
        
        # Info section
        st.subheader("ℹ️ Information")
        st.info("""
        This tool retrieves papers from arXiv, 
        generates summaries, and produces peer reviews.
        
        **Free Mode**: Uses HuggingFace models (no API costs)
        **Premium Mode**: Uses OpenAI models (requires API key)
        """)
    
    # Main content area
    col1, col2 = st.columns([3, 1])
    
    with col1:
        st.header("🔍 Paper Analysis")
    
    with col2:
        if st.session_state.results:
            # Download button
            json_str = json.dumps(st.session_state.results, indent=2, default=str)
            st.download_button(
                label="📥 Download Results (JSON)",
                data=json_str,
                file_name="paper_analysis_results.json",
                mime="application/json"
            )
    
    # Process button
    if st.button("🚀 Process Paper", type="primary", use_container_width=True):
        if not query:
            st.error("❌ Please enter a search query")
        else:
            # Initialize progress
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            try:
                # Step 1: Initialize pipeline
                status_text.text("🔧 Initializing pipeline...")
                progress_bar.progress(10)
                
                if use_free_models:
                    # Override models for free mode
                    actual_summarizer = "bart" if summarizer_model == "openai" else summarizer_model
                    actual_review = "facebook/bart-large-cnn"
                    status_text.text("🔧 Using free models (no API key required)...")
                else:
                    actual_summarizer = summarizer_model
                    actual_review = review_model
                    status_text.text("🔧 Using OpenAI models...")
                
                pipeline = ResearchPaperPipeline(
                    summarizer_model=actual_summarizer,
                    review_model=actual_review,
                    max_results=max_results,
                    use_free_models=use_free_models
                )
                
                # Step 2: Process paper
                status_text.text(f"🔍 Retrieving papers for: '{query}'...")
                progress_bar.progress(20)
                
                result = pipeline.process_paper(
                    query=query,
                    query_type=query_type,
                    evaluate=evaluate
                )
                
                if 'error' in result:
                    progress_bar.progress(100)
                    status_text.text("❌ Error occurred")
                    time.sleep(1)
                    progress_bar.empty()
                    status_text.empty()
                    display_results(result)
                    return
                
                progress_bar.progress(60)
                status_text.text("📝 Generating summary...")
                
                progress_bar.progress(75)
                status_text.text("🔍 Generating review...")
                
                if evaluate:
                    progress_bar.progress(85)
                    status_text.text("📊 Computing evaluation metrics...")
                
                progress_bar.progress(95)
                status_text.text("✨ Finalizing results...")
                
                # Store results
                st.session_state.results = result
                st.session_state.verbose = verbose
                
                progress_bar.progress(100)
                status_text.text("✅ Complete!")
                
                # Small delay to show completion
                time.sleep(0.5)
                progress_bar.empty()
                status_text.empty()
                
                # Display results
                display_results(result)
                
            except Exception as e:
                st.error(f"❌ Error occurred: {str(e)}")
                st.exception(e)
                progress_bar.empty()
                status_text.empty()
    
    # Display previous results if available
    if st.session_state.results:
        st.markdown("---")
        st.header("📊 Results")
        
        # Check if we should show verbose output
        show_verbose = st.session_state.get('verbose', False)
        
        # Re-display with current verbose setting
        display_results(st.session_state.results)
    
    # Footer
    st.markdown("---")
    st.markdown(
        """
        <div style='text-align: center; color: #666; padding: 2rem;'>
        <p>Research Paper Summarizer & Reviewer | Built with Streamlit</p>
        <p>Project by: VIHAS ADI, AKSHITHA BAIRA</p>
        </div>
        """,
        unsafe_allow_html=True
    )


if __name__ == "__main__":
    main()

