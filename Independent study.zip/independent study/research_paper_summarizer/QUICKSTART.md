# Quick Start Guide

## Installation (5 minutes)

1. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Choose your setup:**
   
   **Option A: FREE (No API key needed!)**
   - Just use `--use-free-models` flag - that's it!
   - See [FREE_MODELS_GUIDE.md](FREE_MODELS_GUIDE.md) for details
   
   **Option B: OpenAI API (requires payment)**
   - Create a `.env` file in the project root
   - Add your OpenAI API key:
     ```
     OPENAI_API_KEY=sk-your-actual-key-here
     ```
   - Get your API key from: https://platform.openai.com/api-keys

3. **Test installation:**
   ```bash
   python test_setup.py
   ```

## Basic Usage

### Example 1: Summarize a paper by keywords (FREE)
```bash
python main.py --query "transformer neural networks" --use-free-models
```

### Example 1b: With OpenAI (requires API key)
```bash
python main.py --query "transformer neural networks"
```

### Example 2: Get a paper by title
```bash
python main.py --query "Attention Is All You Need" --query-type title
```

### Example 3: Process with verbose output
```bash
python main.py --query "machine learning" --verbose --output results.json
```

## What You Get

For each paper, the system generates:
- **Summary**: Comprehensive abstractive summary
- **Peer Review**: Structured review with:
  - Contributions
  - Strengths & Weaknesses
  - Technical Quality Assessment
  - Future Directions
- **Metrics**: ROUGE and BLEU scores (if evaluation enabled)

## Troubleshooting

**Problem**: `OPENAI_API_KEY not found`
- **Solution**: Use `--use-free-models` flag for free usage, OR set up `.env` file with API key

**Problem**: Want to use free models?
- **Solution**: Add `--use-free-models` flag to any command. No API key needed!

**Problem**: Import errors
- **Solution**: Run `pip install -r requirements.txt` again

**Problem**: NLTK data missing
- **Solution**: Run `python -c "import nltk; nltk.download('punkt')"`

**Problem**: No papers found
- **Solution**: Try different keywords or check your internet connection

## Next Steps

- Read the full [README.md](README.md) for detailed documentation
- Check [example_usage.py](example_usage.py) for code examples
- Experiment with different models: `--summarizer-model bart` or `--summarizer-model pegasus`

