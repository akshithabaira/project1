# Web UI Quick Start Guide

## Getting Started

### 1. Install Dependencies

Make sure you have all dependencies installed:
```bash
pip install -r requirements.txt
```

### 2. Launch the UI

Run the Streamlit application:
```bash
streamlit run app.py
```

The UI will automatically open in your browser at `http://localhost:8501`.

## Using the UI

### Step 1: Enter Your Search Query

In the sidebar, enter your search query:
- **Keywords**: e.g., "machine learning", "transformer attention"
- **Title**: e.g., "Attention Is All You Need"
- **Author**: e.g., "Vaswani"

### Step 2: Select Query Type

Choose the appropriate query type from the dropdown:
- **Keywords**: General keyword search
- **Title**: Search by paper title
- **Author**: Search by author name

### Step 3: Configure Model Settings

**Free Models (Recommended for first-time users):**
- ✅ Check "Use Free Models (No API Key Required)"
- Uses HuggingFace models (BART/PEGASUS)
- No API costs
- Slightly slower but completely free

**Premium Models (Requires OpenAI API Key):**
- ❌ Uncheck "Use Free Models"
- Requires `OPENAI_API_KEY` in `.env` file
- Faster and potentially better quality
- Incurs API costs

### Step 4: Adjust Processing Options

- **Max Results**: Number of papers to process (1-5)
- **Compute Evaluation Metrics**: Enable/disable ROUGE and BLEU scores
- **Verbose Output**: Show detailed section summaries

### Step 5: Process Paper

Click the **"🚀 Process Paper"** button to start analysis.

You'll see:
- Progress bar showing current step
- Status messages
- Real-time updates

### Step 6: View Results

Results are displayed in organized sections:

1. **Paper Information**: Title, authors, publication date, arXiv ID, URL
2. **Evaluation Metrics**: ROUGE-1, ROUGE-2, ROUGE-L, BLEU scores
3. **Summary**: Full paper summary (expandable)
4. **Section Summaries**: Detailed summaries by section (if verbose)
5. **Peer Review**: Complete peer review analysis (expandable)
6. **Structured Review Components**: Detailed review breakdown (expandable)

### Step 7: Download Results

Click the **"📥 Download Results (JSON)"** button to save results to a JSON file.

## UI Features

### Sidebar Configuration
- All settings in one place
- Real-time validation
- Helpful tooltips

### Main Display Area
- Clean, organized layout
- Expandable sections for detailed views
- Color-coded metrics
- Clickable paper URLs

### Progress Tracking
- Visual progress bar
- Status messages
- Error handling with detailed messages

## Tips

1. **Start with Free Models**: Test the system without API costs
2. **Use Keywords**: Most flexible search option
3. **Enable Verbose**: Get more detailed insights
4. **Download Results**: Save for later reference
5. **Multiple Papers**: Increase "Max Results" to process multiple papers

## Troubleshooting

### UI Won't Start
- Check if Streamlit is installed: `pip install streamlit`
- Ensure you're in the correct directory
- Check for port conflicts (default: 8501)

### No Results Found
- Try different keywords
- Check query type (keywords vs title vs author)
- Verify internet connection (needed for arXiv access)

### API Errors
- Check `.env` file for `OPENAI_API_KEY` (if using premium models)
- Switch to free models if API key is missing
- Verify API key is valid and has credits

### Slow Processing
- Free models are slower but free
- Premium models are faster but cost money
- Processing time depends on paper length

## Keyboard Shortcuts

- `R`: Rerun the app
- `C`: Clear cache
- `?`: Show keyboard shortcuts

## Need Help?

- Check the main [README.md](README.md) for detailed documentation
- Review [FREE_MODELS_GUIDE.md](FREE_MODELS_GUIDE.md) for free model usage
- All terminal features are available in the UI!

