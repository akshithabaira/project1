# Using Free Models (No OpenAI API Required)

## Overview

This project can work **completely free** without requiring an OpenAI API subscription! You can use free HuggingFace models instead.

## Cost Comparison

- **OpenAI API**: Requires payment (pay-per-use, typically $0.002-0.02 per request)
- **Free HuggingFace Models**: Completely free, runs locally on your computer

## How to Use Free Models

### Option 1: Command Line Flag

Simply add the `--use-free-models` flag:

```bash
python main.py --query "machine learning" --use-free-models
```

### Option 2: Automatic Fallback

If you don't set `OPENAI_API_KEY`, the system will automatically try to use free models.

## Free Models Available

### For Summarization:
- **BART** (`facebook/bart-large-cnn`) - High quality, good for summaries
- **PEGASUS** (`google/pegasus-xsum`) - Optimized for abstractive summarization

### For Review Generation:
- **GPT-2** (default free model) - Basic text generation
- You can use other free models by modifying the code

## Installation for Free Models

1. **Install transformers and PyTorch:**
   ```bash
   pip install transformers torch
   ```

2. **That's it!** No API keys needed.

## Performance Notes

### Free Models:
- ✅ **Pros**: Completely free, no API limits, works offline
- ⚠️ **Cons**: 
  - Slower (runs on your computer)
  - Requires more RAM/disk space
  - First run downloads models (~500MB-2GB)
  - Quality may be slightly lower than GPT-3.5/4

### OpenAI Models:
- ✅ **Pros**: Fast, high quality, no local resources needed
- ⚠️ **Cons**: Costs money, requires internet, API rate limits

## Example Commands

### Using Free Models:
```bash
# Summarization with BART (free)
python main.py --query "neural networks" --summarizer-model bart --use-free-models

# Summarization with PEGASUS (free)
python main.py --query "deep learning" --summarizer-model pegasus --use-free-models

# Full pipeline with free models
python main.py --query "transformer attention" --use-free-models --verbose
```

### Using OpenAI (requires API key):
```bash
# With OpenAI (paid)
python main.py --query "machine learning" --summarizer-model openai
```

## Model Recommendations

### For Best Quality (if you have OpenAI API):
- Summarization: `openai` (GPT-3.5-turbo or GPT-4)
- Review: `gpt-3.5-turbo` or `gpt-4`

### For Free Usage:
- Summarization: `bart` (best free option)
- Review: Free models available (basic quality)

## Troubleshooting Free Models

**Problem**: "Transformers not available"
- **Solution**: `pip install transformers torch`

**Problem**: "Out of memory" error
- **Solution**: Use smaller models or process shorter texts

**Problem**: Models download slowly
- **Solution**: First download takes time (~500MB-2GB). Subsequent runs are faster.

**Problem**: Review quality is low
- **Solution**: Free models have limitations. Consider using OpenAI for reviews if quality is critical.

## System Requirements for Free Models

- **RAM**: At least 4GB (8GB+ recommended)
- **Disk Space**: 2-5GB for model downloads
- **Internet**: Required for first-time model download
- **GPU**: Optional but recommended for faster processing

## Cost Breakdown

### Free Models:
- **Cost**: $0.00
- **Setup Time**: 5-10 minutes (one-time model download)
- **Best For**: Learning, testing, low-volume usage

### OpenAI API:
- **Cost**: ~$0.01-0.10 per paper (depends on length)
- **Setup Time**: 2 minutes (just API key)
- **Best For**: Production use, high-quality requirements

## Recommendation

**For Students/Learning**: Use free models (`--use-free-models`)
**For Production/Research**: Consider OpenAI API for better quality

Both options work! Choose based on your needs and budget.

